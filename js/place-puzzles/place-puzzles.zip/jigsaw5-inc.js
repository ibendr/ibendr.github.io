include(
    "object1", "array1", "dom1", "event1",
		"htmlElement3", "htmlMobile3", "htmlDrag4",
		"shell4", "dropTarget4", "placement1", "placePuzzle5",
		"psyfUpdateScore1", "jigsaw5"
		)

