// ELEMENT class : wrapper for a html element
//  the actual DOM object is the field .it


/* Arguments to Element constructor:

el:   if wrapping or cloning existing element:  DOM element object or "_" + element id
      if creating new element:  tag name
parts:   array of items which are each either -
		{ ... , name:val , ... }  : set of attribute values to set on element
		"..."   : content for text node to create and add to element
		[...]   : arguments for a new child element
cloneArgs:  (if cloning)  [ modifier , object ]  function to be called
		(with object as this) on text in all attribute values and text node
		content of clone
getAtts:  (boolean) - whether to fetch attribute values from DOM
getKids:  (boolean) - whether to fetch child elements, text-nodes

*/

function Element(el,parts,cloneArgs,getAtts,getKids) {
	if (arguments.length==0) return // 'empty' constructor for subclass protos
	var it = null
	this.pa = null
	this.atts = {}
	this.kids = []
	var elType = (typeof el)
	if (elType=="object") {
		if ("nodeType" in el) {    // wrap given element
			it = el
		} }
	else if (elType=="string") {
		if (elType.charAt(0)=="_") { // fetch by id & wrap
			it = document.getElementById(id)
			}
		else {			// create new element
			it = document.createElement(el)
			}
		}
	if (cloneArgs) {
		cloneArgs.splice(0,0,it)
		it = modifiedClone.apply(this,cloneArgs)
		}
	if (it) {
		this.it = it
	  it._jsElObj = this
		if (parts) elementAddParts.call(this,parts)
		if (getAtts) {
			// fetch object attributes from DOM
			}
		if (getKids) {
			// fetch children from DOM
			}
		}
  }

// Methods for Element objects

// Sets the attributes (or quasi-attribute - see dom1.js)
//   on the element itself (this.it),  and updates this.atts.
function elementSetAtts(atts) {
	setNodeAttributes(this.it,atts,this.atts) }
// Get attribute - local copy if possible (or force=true to refetch from DOM)
function elementGetAtt(att,force) {
	if ( (!force) && (att in this.atts)) return this.atts[att]
	var out = this.it.getAttribute(att)
	if (out==undefined) out = null
	else this.atts[att] = out
	return out	}

function elementAddChild(x)  {  // x is an Element object NOT DOM object
	x.setAtts({parent:this.it}) // DOM object parent is DOM object
	x.pa=this		 // JS object parent is JS object
	this.kids.push(x)
  }
function elementAddNewChild() {
//		var kid = new Element // gets protoype properties only for now
//		Element.apply(kid,arguments)
		elementAddChild.call( this, newapply(Element,arguments) )
		}
function elementAddParts (parts) {
	// sets attributes,  adds new text nodes and elements
	for (var i=0; i<parts.length; i++) {
		var part=parts[i]
		if ((typeof part)=="string") {		// text node
			this.it.appendChild(document.createTextNode(part))
			this.kids.push(part) }
		else if (part instanceof Array) { 	// sub-element
			elementAddNewChild.apply(this,part)
			this.kids.push(part) }
		else if (part instanceof Object)	// attributes
			elementSetAtts.call(this,part)
	}	}

Element.prototype = {
	setAtts : elementSetAtts,
	getAtt : elementGetAtt,
	addChild : elementAddChild,
	addParts : elementAddParts,
	addNewChild : elementAddNewChild,
	remove : function () {
		if (this.it) {
			// to allow proper garbage collection and avoid memory leakage
      if (this.it.getAttribute("_jsElObj")) // Explorer
				this.it.removeAttribute("_jsElObj")
      else delete this.it._jsElObj          // Mozilla
    	this.it.parentNode.removeChild( this.it )	// take element out of document
			delete this.it	// AND destroy it (hopefully)
			}
		if (this.pa) this.pa.kids.remove(this)
		},
	empty : function () {     // no guarantee this will work -
					// a browser might keep re-attaching child nodes to an element.
		while (this.it.lastChild) this.it.removeChild(this.it.lastChild) },
	setText : function (t) { setNodeText(this.it,t) },
	hasClass : function (c) { 
		var cs = this.getAtt("class")
		return cs && ( cs.search(new RegExp("\\b"+c+"\\b") ) > -1 )
		},
	addClass : function (c) {
		var cs = this.getAtt("class")
		if (cs) {
			if ( cs.search(new RegExp("\\b"+c+"\\b") ) == -1 ) cs += " " + c
			}
		else cs = c
		this.setAtts({"class":cs})
	  }
	}

function elHasClass(el,cls) {		// Quick class check for use on elements
                //      that we're not wrapping with Element object.
	var c = el.getAttribute && (el.getAttribute("class"))
	return c && ( c.search(new RegExp("\\b"+cls+"\\b") ) > -1 )
  }

