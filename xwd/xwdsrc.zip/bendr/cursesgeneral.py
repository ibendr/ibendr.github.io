#!/usr/bin/python

"""
A module giving the skeleton of a curses application.

Went on to develop into cursesapp

Provides basic open , save , quit , help , redo , undo

Intent:
Rather than having a main loop,  poll() should be called by the main application
at moments which are suitable for it,  e.g. at moments appropriate for 
interrupting a reiterative process (between iterations)

Current:
Testing with bodgy little sample built in here

Uses awkward setup for retrieving info from shell dialogs
"""

import os , sys
import curses as crs

win = None
#scr = None
it  = None
#cursor = None

def dialog( s , justExitCode = False ):
  # Run a dialog via os, with option in s
  #  and return the output as ( str , exit code )
  if justExitCode:
    # easy - we return exit code not text
    out = os.system( 'dialog %s' % s )
  else:
    xcd = os.popen( 'dialog --stdout %s ; x=$? ; echo ; echo $x' % s ).read().splitlines();
    out = ( '\n'.join( xcd[ : -1 ] ) , xcd[ -1 ] )
    ## Ugly workaround while piping not working for us...
    #xcd = os.system( 'dialog --stdout %s > tmp' % s )
    #out = ( file("tmp").read() , xcd )
    #os.system('rm tmp')
  crs.reset_prog_mode() # restore settings after changes by dialog
  if win:
    win.clear()		# clear screen and redraw everything
    if it:
      it.refresh( True )
  return out

class cursesApp( object ):
  """Make a subclass of this as your application."""
  appClass = None #sub #simpleAppClass
  loaded_filename = None
  loaded_object = None
  quitting = False
  history_changes = [ ]
  history_ptr = 0
  history_saved = 0
  hotkeys = {
     #1 : "All Select" ,
     #2 : "None Select" ,
     #3 : "Copy Edit" ,
     #4 : "Delete Edit" ,
    14 : "New File" , 
    15 : "Open File" ,
    17 : "Quit" ,
    18 : "Reload File" ,
    19 : "Save File" ,
    20 : "SaveTo File" ,
    #22 : "Paste Edit" ,
    23 : "Close File" ,
    #24 : "Cut Edit" ,
    25 : "Redo Edit" ,
    26 : "Undo Edit" ,
    #27 : "Escape" ,
    0x102 : ( "Move" , 1 ) ,
    0x103 : ( "Move" , 3 ) ,
    0x104 : ( "Move" , 2 ) ,
    0x105 : ( "Move" , 0 ) ,
    0x152 : ( "Move Page" , 0 ) ,
    0x153 : ( "Move Page" , 1 ) ,
    0x109 : "Help"
    }
  hotkeyFuncs = None
  briefHelp = None

  @classmethod
  def _make_hotkey_func_list( cls ):
    # Make the classes hotkeyFuncs array if not already done
    clsDir = dir( cls )  
    clsNam = cls.__name__
    if not cls.hotkeyFuncs:
      cls.hotkeyFuncs = {}
      for key,fnam in cls.hotkeys.items():
	if isinstance ( fnam , str ):
	  nam , fargs = fnam , ()
	else:
	  nam , fargs = fnam[ 0 ], fnam[ 1 : ]
	name = "_cmd_" + nam.replace(' ','_')
	if name in clsDir:
	  # There must be a better way - this is shitful
	  cls.hotkeyFuncs[ key ] = ( eval( clsNam + '.' + name ) , fargs )
      if not cls.briefHelp:
	# brief help is hotkey assignments with their original
	#   string descriptions where their actual methods exist
	cls.briefHelp = '\n'.join( [ "%s   :    %s " %
		( crs.keyname( k ) , cls.hotkeys[ k ] ) for k in cls.hotkeyFuncs ] )
    
  def __new__( cls ):
    #print cls , dir( cls )
    out = object.__new__( cls )
    print out.appClass
    cls._make_hotkey_func_list( )
    return out

    # methods for subclasses to implement
  def refresh( self , total = False ):
    # set total = True to redraw everything about the object's display,
    #  ( assuming something e.g. dialog has drawn over it all )
    # Otherwise only what has (or may have) changed since last refresh -
    #  up to individual app as to how smart it wants to be about it
    pass
  def inner_loop( self ):
    # should return 0 (or False / None) to continue looping
    #  otherwise 'exit code'
    return "Code error: inner_loop not implemented by subclass of cursesApp"
  def subpoll( self , k ):
    # Respond to keycode k
    # should return True if used or exit code (!= True ) to break loop
    # return False / None if keycode was unused
    pass
  
  # default to and from lines of text methods, for file ops
  def _to_lines( self ):
    return str( self.loaded_object ).splitlines()
  def _from_lines( cls , lines ):
    return cls.appClass and cls.appClass( lines )
  
  
  # Command functions - method name is significant _cmd_ + ...
  
		# File functions

  def _check_Saved( self ):
    # Return True if ok to go ahead and close / quit / etc.
    # Alas we have no Yes/No/Cancel box so we can't offer
    # to save from here - just query going ahead with unsaved close
    # Easy case - we're saved up to date anyway
    if self.history_ptr == self.history_saved:
      return True
    # Otherwise check is user wants to do a save
    qry = dialog( '--yesno "Are you sure you wish to close\n\
	    %s without saving changes?" 12 48' % self.loaded_filename , True )
    return ( qry == 0 )
  def _cmd_Close_File( self ):
    #returns True if close has failed - 
    # i.e. file still open (unsaved) and user Cancelled
    if not self.loaded_object:
      # Nothing to close - OK
      return None #True
    if self._check_Saved( ):
      # Unsaved but user OK
      # close displays etc.?
      self.loaded_filename = None
      self.loaded_object = None
      self.refresh( True )
      return False #True
    else:
      # Unsaved, cancelling close
      return True #False
  def _cmd_Help( self ):
    s = self.briefHelp
    if s:
      dialog( '--msgbox "%s" 20 60' % s , True ) 
  def _cmd_Quit( self ):
    # Check for saving work?
    if not self._cmd_Close_File( ):
      #self.quitting = True
      return "QUIT"
    else:
      return "QUIT anyway"
  def _load_file( self , fn ):
    if fn:
      win.addstr( 14 , 4 , "Opening file %s " % fn )
      try:
	inp = file( fn ).readlines()
      except:
	win.addstr( 15 , 4 , "Failed to open file" )
	inp = None
      if inp:
	self.loaded_object   = self._from_lines( inp )
	self.loaded_filename = fn
	self.history_changes = [ ]
	self.history_ptr     =  0
	self.history_saved   =  0
	self.refresh( True )
  def _cmd_Open_File( self ):
    if not self._cmd_Close_File( ):
      fn = dialog( '--fselect "" 20 60' )[ 0 ]
      self._load_file( fn )
  def _save_file( self , fn ):
    win.addstr( 14 , 4 , "Opening file %s for saving  " % fn )
    try:
      fil = file( fn , "w" )
      fil.writelines( self._to_lines() )
      fil.close ()
      self.loaded_filename = fn
      self.history_saved = self.history_ptr
    except:
      win.addstr( 15 , 4 , "Failed to open file" )
  def _cmd_Save_File( self ):
    # Check if we have a filename to save back to
    if self.loaded_filename and self.loaded_object:
      # Check if any changes since save
      if self.history_ptr != self.history_saved:
	# OK, now save
	self._save_file( self.loaded_filename )
  def _cmd_SaveTo_File( self ):
    fn = dialog( '--fselect "" 20 60' )[ 0 ]
    if fn:
      if os.path.isfile( fn ):
	#return "exists"
	qry = dialog( '--yesno "The file %s already exists.\n \
		      Do you want to overwrite it?" 10 30' % fn , True )
	if qry:
	  return
      self._save_file( fn )
      self.refresh( True )

		# Edit history commands - redo and undo
  
  def _cmd_Redo_Edit( self ):
    # Can only do a redo if we're not at the end of the history
    if self.history_ptr < len( self.history_changes ):
      for change in self.history_changes[ self.history_ptr ]:
	change[ 0 ][ 0 ]( self.loaded_object , * change[ 0 ][ 1: ] )
      self.history_ptr += 1
      self.refresh()
  def _cmd_Undo_Edit( self ):
    # Can only do an undo if we're not at the start of the history
    if self.history_ptr > 0:
      self.history_ptr -= 1
      for change in self.history_changes[ self.history_ptr ][ :: -1 ]:
	change[ 1 ][ 0 ]( self.loaded_object , * change[ 1 ][ 1: ] )
      self.refresh()
  def doChange( self , change ):
    """Put a change on the history, replacing tail thereof,
     and execute the change"""
    # Dock tail of history
    self.history_changes[ self.history_ptr : ] = [ ]
    # Add change - will be pointed to as next redo, so can call redo
    self.history_changes.append( change )
    self._cmd_Redo_Edit( )
  def poll ( self ):
    # Check for keypresses and call appropriate methods
    #  returning non-zero only if main loop should be interrupted
    k = win.getch()
    if k != -1:
      win.addstr( 3 , 20 , "%s   %s    " % ( hex( k ) , crs.keyname( k ) ) )
    if k in self.hotkeyFuncs:
      func , fargs = self.hotkeyFuncs[ k ]
      return func( self , * fargs )
    else:
      # see if subclass has a use for the keycode
      kk = self.subpoll( k )
      if kk == True:
	return
      else:
	if kk:
	  return kk
	else:
	  # unknown keycode
	  win.addstr( 4 , 30 , " Inactive keycode - %s   " % hex( k ) )
	  return

# ------------------------------------------------------------------------------
#
#   Below this point is test material, which would usually be in a separate file
#
#-------------------------------------------------------------------------------

#some testing - a trivial little subclass of cursesApp - list of lines of text
# of which we'll display top-left 8x8 section, no edit for now


def strListSetChar( l , y , x , c ):
  l[ y ] = l[ y ][ : x  ] + c + l[ y ][ x + 1 : ]

def strListSetSlice( l , y , x0 , x1 , s ):
  l[ y ] = l[ y ][ : x0 ] + s + l[ y ][ x1 : ]

class sub( cursesApp ):
  appClass = list
  cursor = None
  def __init__( self ):
    self.scr = win.subwin( 10 , 10 , 2 , 2 )
    self.scr.box()
    self.cursor = 0,0
    pass
  def _to_lines( self ):
    return self.loaded_object
  def subpoll( self , k ):
    if 32 <= k < 125:
      obj , ( y , x ) = self.loaded_object , self.cursor
      if obj:
	# change object!
	row = obj[ y ]
	if x < len ( row ):
	  # easy case
	  old = row[ x ]
	  # setup a change chain - pairs of  ( do ,  undo )
	  change = ( (   ( strListSetChar , y , x , chr( k ) ) , 
			( strListSetChar , y , x ,   old    )    ) , )
	else:
	  # this time have to append some spaces and the new letter
	  x0 , x1 , dx = len( row ), x + 1 , x - len( row )
	  change = ( (   ( strListSetSlice , y , x0 , x1 , dx * " " + chr( k ) ) ,
			( strListSetSlice , y , x0 , x1 , ""                  )   ) , )
	self.doChange( change )
	self._cmd_Move( )
	self.refresh()
	return True
	
  def _cmd_Move( self , dirn = 0 ):
    out = list( self.cursor )
    ax , dn = 1 - ( dirn & 1 ) , dirn & 2
    out[ ax ] += 1 - ( dn )
    if ( dn ):
      # backward - check left / top i.e. zero
      while out[ ax ] < 0:
	out[ ax ] = 7
	# and also move vertically IF we were moving horizontally
	if ax:
	  ax = 0
	  out[ ax ] -= 1
	  # and the while loop then checks for vertical wraparound
    else:
      while out[ ax ] >= 8:
	out[ ax ] = 0
	# and also move vertically IF we were moving horizontally
	if ax:
	  ax = 0
	  out[ ax ] += 1
	  # and the while loop then checks for vertical wraparound
    self.cursor = tuple( out )
    self.refresh()

  def refresh( self , total = False ):
    # taken from earlier trial - cursegrid.py
    it , scr = self.loaded_object , self.scr
    if scr:
      if total:
	# do border, title etc.
	scr.clear()
	scr.box()
	if self.loaded_filename:
	  scr.addstr( 0 , 2 , self.loaded_filename[ -6 : ] ) 
      if it:
	for y,row in enumerate( it[ : 8 ] ):
	  for x,c in enumerate( row[ : 8 ] ):
	    scr.addch( 1 + y , 1 + x , c )
      if self.cursor:
	scr.move( 1 + self.cursor[ 0 ] , 1 + self.cursor[ 1 ]  )
	scr.cursyncup()
      scr.refresh()

def main( wind , *args ):
  global it , win
  crs.raw() # Should only be used when we are confident we can arrange exit
	      # since we lose the interception of ctrl-C
  crs.def_prog_mode()  # protect setting from changes by other processes
  win = wind
  it = sub()
  if len( args ) > 1:
    # try and load a file
    it._load_file( args[ 1 ] )
    #it.refresh()
  # crude loop
  ret = 0
  while not ret:
    it.inner_loop()
    ret = it.poll()
  return ret

if __name__ == "__main__":
  print crs.wrapper( main , *sys.argv )
