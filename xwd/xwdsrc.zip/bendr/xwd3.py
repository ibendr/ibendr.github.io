#!/usr/bin/python

"""
Abstract crossword class

code reworked from an5
"""

import sys , subprocess , re
import random


wordLists = { }		# loaded word lists as { len : [ ... ] , ... }
debug = 0		# level of verbosity of comments
checkFilled  = False    # whether or not to check validity of words alread in the grid
allowRepeats = False    # whether a word may appear more than once in the grid
keepSingletons = False
allowUpper = True
interactive = False

# Constants

directionNames = "Across" , "Down"
dirnNamC = "a" , "d"

matchesPending = [] ; collisions = []
fileRoot = "words-len-"
lenLimit = 19

# Various characters of significance

ABC = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
abc = ABC.lower()

cAlphas = ABC + abc

# characters used to denote live cells (input and output),
# and number of possibile letters (as output)
cWilds = "123456789;;;;::::,,,,.... "

cClash = '*'     # to record a contradiction     \
cBlock = '+='    # possible blocking characters  /  both unused (?)

cCells = cAlphas + cWilds + cClash

cEnds = "|#/\\<>"  # characters denoting end of line of crossword (comments etc. may follow)

# For pretty formatting progress monitor with indents...
cPrefixForce = '-'
cPrefixPosit = '|'

# cell and spot classes are structural info only - content or possible content elsewhere

class cell:
  # A cell is a square of the crossword ( in which one letter / character is entered )
  # These are class default values,  and illustrative of format
  pos = ( 0 , 0 )	# position on grid
  spots = ( )		# A tuple ( sp , n ) for each spot it is part of ...
			#  sp is pointer to spot and n its position ( index ) in that spot
  def __init__( I , i , j ):
    I.pos = ( i , j )
  def __repr__( I ):
    if I.pos[ 0 ] >= 25 or I.pos[ 1 ] >= 25:
      return ABC[ I.pos[ 1 ] / 25 ] + ABC[ I.pos[ 1 ] % 25 ] + \
	     abc[ I.pos[ 0 ] / 25 ] + abc[ I.pos[ 0 ] % 25 ]
    # Print row first for correct ordering
    return ABC[ I.pos[ 1 ] ] + abc[ I.pos[ 0 ] ]

class spot:
  # A spot is a sequence of cells - ( in which a word is entered )
  # This class now DOES record the direction and label number of a spot,
  # but not automatically at _init__.  Likewise name
  cells = ( )	# The cells of the spot - default value with no cells shouldn't get used
  dirn  = -1
  numb  = -1
  nam   = ""
  nameL = ""
  def __len__( I ):
    # length of spot is how many cells in it - hence equal to length of word required
    return len( I.cells )
  def __str__( I ):
    """Return short name if available, else cell-based name"""
    return I.nam   or I.__repr__ ( )
  def __repr__( I ):
    """cell based name - strung together cell names  e.g.  De-Ee-Fe-Ge-He"""
    return '-'.join( [ c.__repr__() for c in I.cells ] )
  def setLabels( I , d , n ):
    I.dirn , I.numb = d , n
    I.nam   = "%2d%s" % ( I.numb , dirnNamC[ I.dirn ] ) 
    I.nameL = "%2d. %s" % ( I.numb , directionNames[ I.dirn ] )

# Stuff to deal with "content" - a set of possible values of a cell

def regExpContentC( cont ):
  # make a chunk of regular expression based on options for content
  # All word lists are imported as upper and we just work in upper
  conL = list( cont )
  if len( conL ) == 1:
    return conL[ 0 ]
  return '[' + ''.join( conL ) + ']'

def regExpContentW( sp , cont ):
  # make the full regular expression for the possibilities for a spot
  # cellContent object has to be passed as cont since it is not global
  return ''.join( [ regExpContentC( cont[ cl ] ) for cl in sp.cells ] )

def showContentSpot( cont , sp , blanks = None ):
  # What to display ( one character per cell ) for possibilities for a spot
  #  stringing together characters from showContent()
  # NB: in this case cont is the whole I.cellContent object!
  return ''.join( [ showContent( cont[ cl ] , blanks )
			for cl in sp.cells ] )
def showContent( cont , blanks = None ):
  # What to display ( in one character ) for a given set of possibilities
  # cont is a set of letters ( for a cell )
  # use blanks = " " (or other) to leave undetermined cells blank, otherwise
  # characters are provided to hint at number of possibilities remaining
  l = len( cont )
  if l == 0:	return cClash
  if l == 1:	return list( cont )[ 0 ]
  return blanks or cWilds[ min ( l , 26 ) - 1 ]

def showLabel( lbl ):
  return directionNames[ lbl[ 0 ] ] + ' ' + str( lbl[ 1 ] )

class xwd( object ):
  
  contradiction = False
  dispPrefix = ""
  
  def __init__( I , src = None , raw = False ):
    """
    src should be a filename or a list of lines of text
    Use raw = True to avoid analysis
    """
    if debug >=3: print lines
    
    I.width        = 0
    I.height       = 0
    
    I.cells        = [ ]	# flat list of all the cells
    I.cellByPos    = [ ]	# cell or None references by I.cellByPos[ j ][ i ]
    
    I.spots        = [ [ ] , [ ] ]     # Across and down spots - lists of pointers to cells
    
    I.cellLabels   = dict()            # Number / label in cell
    #I.spotLabels   = dict()            # ( d , n ) where d is direction: 0 Across, 1 Down
			               ## and n is label in head cell (usually number)
    
    I.cellContent  = dict()	# Possible content for the cells, as sets of possibilities
			  # After processing -
			  # dictionary from cell (ptr) to a set of of permitted letters
			  #  .... dict of letter -> [ n0 , n1 ] lists
			  # where letter is a letter which could go in the cell, and
			  # n0 , n1  are the number of words currently permissible (in
			  # the across and down spots respectively) which agree with
			  # this letter assignment;  one for unused direction.  (Zero
			  # should not occur 'naturally' or else letter not in set
			  # At input stage - 
			  # dictionary from cell(ptr) to string (content) or number (priority)
    I.spotContent = dict()    # Possible content for the spots, as lists of words
    I.spotRegExp  = dict()
    
    I.wordsUsed  = set()      # words already used -> to avoid repeats
    
    I.spotsToAdjust = set()   # spots that need adjustment
    I.posits = []             # trialled entries - linked with cull history
    I.cullHistory = []
    I.cullHistoryNew()        # sets up I.cullHistory , I.cullSpots , I.cullCells

    if src:
      if isinstance ( src , list ) and src and \
	    isinstance ( src[ 0 ] , str ):
	I.from_lines( src )
	if not raw:
	  I.analyse( )
      elif isinstance( src , str ) and src:
	I.from_lines( file( src ).read().splitlines() )
	if not raw:
	  I.analyse( )
    
  def to_lines( I ):
    return [ ''.join( [ ( c and showContent( I.cellContent[ c ] , " " ) ) or "="
		for c in cellRow ] ) + "|" for cellRow in I.cellByPos ] + [ "" ]
  def from_lines( I , lines ):  
    if debug>1: print "Establishing crossword structure..."

    # On the fly building of Across and Down spots ...
    #   ... a little tricky - reading cells in rows, so at any given
    #     time there is only one 'live' Across clue but several live
    #     Down clues.  Initially we allow spots of length 1,
    #     to save 'looking ahead' at next row.  Then cull afterwards.

    spotNowAcc = None	# Current 'across' spot
    spotsNowDn = dict()	# Current 'down' spots for each column

    for j,line in enumerate( lines ):
      cellRow = [ ]
      if not line:
	break
      for i,c in enumerate( line ):
	if c in cEnds:
	  # end of line - ignore following
	  i -= 1	# point to correct width
	  break
	else:
	  if c in cCells:
	    # cell of crossword
	    newCell = cell( i , j )
	    if not spotNowAcc:
	      spotNowAcc = spot()
	      I.spots[ 0 ].append( spotNowAcc )
	    if not i in spotsNowDn:
	      spotsNowDn[ i ] = spot()
	      I.spots[ 1 ].append( spotsNowDn[ i ] )
	    I.cells.append( newCell )
	    cellRow.append( newCell )
	    spotNowAcc.cells += ( newCell, )
	    spotsNowDn[ i ].cells += ( newCell, )
	    if c in cAlphas:
	      I.cellContent[ newCell ] = set( [ c.upper() ] )
	      n = 1
	    else:
	      # Wildcard ... have to allow everything at first
	      I.cellContent[ newCell ] = set( ABC )   # can only populate later
	      n = cWilds.find( c ) + 1	#  n == 0  means  c == cClash
	    #I.cellScores[ newCell ] = n
	  else:
	    # assume block - could check == cBlock if requiring strict adherence
	    cellRow.append( None )
	    # Close current spots - remove from list if too short (now defered)
	    if spotNowAcc:
	      spotNowAcc = None
	    if i in spotsNowDn:
	      del spotsNowDn[ i ]
      # End of the line - finish off current across spot 
      if spotNowAcc:
	spotNowAcc = None
      I.cellByPos.append( cellRow )
      # seems bug-using to reference i outside what should be its scope,
      #  but it's convenient  -  will hold last valid value i.e. 1 less than width
      # I've checked and this is a documented and valued feature of python -
      #  the for loop is NOT a block so doesn't define separate scope
      if i >= I.width:
	I.width = i + 1
    # End of file
    # extend any short rows, so cellByPos has values for all valid i,j
    for cellRow in I.cellByPos:
      while len( cellRow ) < I.width:
	cellRow.append( None )
    I.height = len( I.cellByPos )
    # Cull out any singleton spots and assign remaining spots to cells
    for d in 0,1:
      # Must use a ( slice ) copy of spots list because we are culling from original list
      for sp in I.spots[ d ][ : ]:
	if keepSingletons or len( sp ) > 1:
	  for i,cl in enumerate( sp.cells ):
	    cl.spots += ( ( sp , i ) , )
	else:
	  I.spots[ d ].remove( sp )
    # This will sometimes be convenient - and costs very little memory
    I.allSpots = I.spots[ 0 ] + I.spots[ 1 ]
    # Only after culling of singletons do we do cell and spot labels...
    headCells = list( set( [ sp.cells[ 0 ] for sp in I.allSpots ] ) )
    headCells.sort( None , repr )	# Sorts alphabetically with our Ce notation and hence
				  # in correct order of grid appearance
    # Number the cells that are the heads of spots ("head cells")
    for i,cl in enumerate( headCells ):
      I.cellLabels[ cl ] = i + 1
    # Then we can label the spots by direction and number in the customary manner
    for d in 0,1:
      for sp in I.spots[ d ]:
	sp.setLabels( d , I.cellLabels[ sp.cells[ 0 ] ] )
	#labels = ( d , I.cellLabels[ sp.cells[ 0 ] ] )
	#I.spotLabels[ sp ] = labels
	#sp.dirn , sp.numb  = labels
    return
  
  def cullHistoryNew( I ):
    """
    Start on a new block of cull history
    """
    I.cullSpots = { }   # spot : set of removed possibilities
    I.cullCells = { }   # cell : set of removed possibilities
    I.cullHistory.append( ( I.cullSpots , I.cullCells ) )
  
  def analyse( I ):
    """Do first analysis"""
    I.fetchWordLists()
    I.initAnalyse()
    # This is where we start a new cull history object
    # Note that adding these cull lists to the history
    #  does not remove them from view as I.cull<...> , so further
    #  culls can still be added (by subsequent analysis / posit)
    I.outerAnalyse()
    I.cullHistoryNew( )
    
  def posit( I , sp = None , w = None , depth = 1 ):
    """Try putting the word w in spot sp.
    Adjust spot and cell content, flag other spots affected,
    then do analysis if depth > 0 and
    recursive positing if depth > 1
    """
    if not sp:
      # By default we use the most restricted live spot (least possible words)
      spots = sorted( I.liveSpots.items() , None , lambda x:x[ 1 ] )
      if len( spots ):
	sp = spots[ 0 ][ 0 ]
      else:
	# No live spots left, grid must be (successfully?) filled
	return not I.contradiction
    oldList = I.spotContent[ sp ]
    # Return False (failed) if no words in the list, or w not in list
    if not oldList: return False
    if w:      
      if not w in oldList: return False
      if ( not allowRepeats ) and w in I.wordsUsed: return False
    #else:
      ## Default is a random choice of word (smarter strategies may exist)
      #w = random.choice( list( oldList ) )
      
    # Initiate new cull history event
    I.cullHistoryNew( )
    I.posits.append( ( sp , w ) )      
    # put word in
    I.setNewSpotContent( sp , [ w ] , False , "/===>" , cPrefixPosit )

    if depth:
      I.outerAnalyse( )
    
    return not I.contradiction

  def tryToFill( I ):
    I.dispPrefix = ""	# prefix to indicate current depth of search
    #ok = True
    while I.liveSpots:
      # Start of iteration
      # Sort spots with most restricted first
      spots = sorted( I.liveSpots.items() , None , lambda x:x[ 1 ] )
      sp = spots[ 0 ][ 0 ]
      cont = I.spotContent[ sp ]
      w = random.choice( list ( cont ) )
      #I.dispPrefix += '"'
      I.fullPosit( sp , w )
    # run out of live spots without a clash - must be done 
    return not I.contradiction

  def fullPosit( I , sp , w ):
    """posit word w in spot sp, and retract as necessary - which
    could extend to retracting a previous posit!"""
  
    I.posit( sp , w ) # starts new history event
    while I.contradiction:
      # Last posit failed,  withdraw it
      if I.posits:
	sp , w = I.posits.pop( )
	# Trim from last " in prefix
	I.dispPrefix = I.dispPrefix[ : 
	      - I.dispPrefix[ : : - 1 ].index( cPrefixPosit ) - 1 ]
	if debug:
	  print "%s\ %s" % ( I.dispPrefix , sp ) #, w.lower() )
	I.undoLastCull( ) # removes history event -
	I.contradiction = False
	I.setNewSpotContent( sp , set( ( w, ) ) , True )
	# This analysis may find a contradiction before we
	# get to do another posit,  hence this while loop
	I.outerAnalyse( )
      #else:
	## Ran out of posits to retract... search exhausted, failed
	#return False
    #return True

  def undoLastCull( I ):
    cullSpots , cullCells = I.cullHistory.pop( )
    for sp , culls in cullSpots.items():
      if len( I.spotContent[ sp ] ) == 1:
	# going back up from single possibility, i.e.
	# retracting commitment of a word
	I.wordsUsed -= I.spotContent[ sp ]
      I.spotContent[ sp ].update( culls )
      I.liveSpots[ sp ] = len( I.spotContent[ sp ] )
    for cl , culls in cullCells.items():
      I.cellContent[ cl ].update( culls )
    I.cullSpots , I.cullCells = I.cullHistory[ -1 ]

  def fetchWordLists( I ):  
    """Fetch relevant word lists - entire lists of required lengths,
    only fetching if not already in memory."""
    global wordLists
    if debug>1: print "Fetching word lists..."
    for sp in I.allSpots:
      l = len( sp )
      if not l in wordLists:
	try:
	  wordL = file( fileRoot + str( l ) ).read().split()
	except:
	  wordL = [ ]
	if not allowUpper:
	  wordLists[ l ] = [ w.upper() for w in wordL if w == w.lower() ]
	else:
	  wordLists[ l ] = [ w.upper() for w in wordL ]
	del wordL

  def initAnalyse( I ):
    I.liveSpots = dict()   # spot : n    where n is number of possibilities left
    I.spotsToAdjust = set( I.allSpots )
    for sp in I.allSpots:
      fixed = True
      for c in sp.cells:
	if not I.cellContent[ c ]:
	  I.contradiction = True
	  I.spotsToAdjust.clear()
	  return
	if len( I.cellContent[ c ] ) != 1:
	  fixed = False
	  break
      if fixed:
	# Pre-filled word
	w = ''.join( [ list( I.cellContent[ c ] )[ 0 ] for c in sp.cells ] )
	if checkFilled:
	  # Make sure it's legal - if required
	  if not w in wordLists[ len( w ) ]:
	    I.contradiction = True
	    I.spotsToAdjust.clear()
	    return
	I.wordsUsed.add( w )
	wl = [ w ]
	if debug > 1: print w ,
	I.spotsToAdjust.remove( sp )
      else:
	wl = wordLists[ len( sp ) ]
	I.liveSpots[ sp ] = len( wl )

      I.spotContent[ sp ] = set( wl )

  def outerAnalyse( I ):
    """
    Recursively go through the list of spots to adjust, restricting
    the cells in accordance with the spot restrictions, and flagging
    other spots that are thus affected (which is to say that if they had
    already been done, they'll be put back on the to-adjust list,
    to be picked up in the next iteration).
    """
    while I.spotsToAdjust and not I.contradiction:
      I.innerAnalyse( )

  def innerAnalyse( I ):
    if debug > 1:    print "Restricting %d spots" % len( I.spotsToAdjust ) ,
    if debug > 3:
      print ; print I.spotReport()

    for sp in list( I.spotsToAdjust ):
      if debug>2: print sp   #showLabel( I.spotLabels[ sp ] )

      # Update the regular expression

      regExp = regExpContentW( sp , I.cellContent )
      I.spotRegExp[ sp ] = regExp
      # Sneaky way to check for only one possibilty - no 'range'
      # indicators (e.g. [asdf] ) in the regular expression is the
      # only way it can be the same length as the spot it applies to
      if len( sp ) == len( regExp ):
	# forced word - but we must check it's a word (pre-filled 
	# words, if allowed unchecked, are 'let in' during initAnalyse( )
	if regExp in wordLists[ len( regExp ) ]:
	  newList = [ regExp ]
	else:
	  newList = [ ]
      else:
	try:
	  regExpComp = re.compile( regExp )
	except:
	  print '%s reg expn : %s ' % ( sp , regExp )
	  print '\n'.join( I.to_lines() )
	  raise "ERROR"
	if allowRepeats:
	  newList = [ w for w in I.spotContent[ sp ]
		    if regExpComp.match( w ) ]
	else:
	  newList = [ w for w in I.spotContent[ sp ]
		    if regExpComp.match( w ) and not w in I.wordsUsed ]
      I.setNewSpotContent( sp , newList )
      if I.contradiction:
	break
    if debug > 1: print

  def setNewSpotContent( I , sp , newList , 
	byCulls = False , forceMsg = "  -> " , prefixXtra = cPrefixForce ):
    # Make newList ( a list ) the new set of possibilities
    # for spot sp,  and accordingly adjust cell contents and 
    # flag other affected spots.  If byCulls = True, use
    # newList argument as ( set ) culls, and skip reporting
    # if forced. forceMsg allows a different description
    # in the case where there is only one possibility
    cont = I.spotContent[ sp ]
    if byCulls:
      #if not newList.issubset( cont ):
	#print sp, newList, cont[:20]
	#raise "hell"
      culls = newList
      keeps = cont - culls
    else:
      #if not set( newList ).issubset( cont ):
	#print sp, newList, cont[:20]
	#raise "hell"
      keeps = set( newList )
      culls = cont - keeps
    newLen = len( keeps )
    
    I.liveSpots[ sp ] = newLen

    if not newLen:
      I.contradiction = ( sp , I.spotRegExp[ sp ] )
      # Contradiction reached as no words left for this spot
      if debug:
	print "%s XXXXX : %s : %s" % ( I.dispPrefix , sp , \
		I.spotRegExp[ sp ].lower() )
	      #showContentSpot( I.cellContent , sp , '.' ).lower() )
      # TODO: provide options here
      I.spotsToAdjust.clear()  # break outer cycle
      return
    if newLen == 1:
	del I.liveSpots[ sp ]
	I.wordsUsed.add( list( keeps )[ 0 ] )
	if debug and not byCulls:
	  print "%s %s : %s : %s " % \
		( I.dispPrefix , forceMsg , sp , newList[ 0 ] )
	  if debug > 2:
	    print '\n'.join( I.to_lines() )
	    raw_input('hit Enter to continue')
	I.dispPrefix += prefixXtra
	  
	if not I.liveSpots:
	  if debug > 2:
	    print "FILL COMPLETED."
	    print '\n'.join( I.to_lines() )
      
    # record changes ( if any )
    
    if culls:
      I.cullSpots.setdefault( sp , set() ).update( culls )
      cont -= culls
      transpose = zip( * keeps )
      newSpotContent = map ( set , transpose ) # turn each column into a set
      for i,cl in enumerate( sp.cells ):
	if len( newSpotContent[ i ] ) < len( I.cellContent[ cl ] ):
	  # Less permitted letters in this cell...
	  if debug > 1:   print cl , i ,
	  culls = I.cellContent[ cl ] - newSpotContent[ i ]
	  if culls:
	    #I.spotScores[ sp ][ i ] = newSpotContent[ i ]
	    I.cellContent[ cl ] -= culls
	    ## DEBUG: catch cells that have run out of possibilities,
	    ##  which shouldn't happen unless newSpotContent was
	    ##  disjoint with I.cellContent[ i ],  i.e. word
	    ##  chosen which didn't fit!
	    #if not I.cellContent[ cl ]:
	      #print sp , i , cl , culls , newSpotContent[ i ]
	      #print [ I.cellContent[ cl1 ] for cl1 in sp.cells ]
	      #print '\n'.join( I.to_lines( ) )
	      #raise 'exception'
	    I.cullCells.setdefault( cl , set() ).update( culls )

	    # Flag other spot(s) it's in

	    for ( sp1, i1 ) in cl.spots:
	      if not sp1 == sp:
		if sp1 in I.liveSpots:
		  I.spotsToAdjust.add( sp1 )

      # Mark this spot as done

    I.spotsToAdjust.discard( sp )

  def spotReport( I , showLen = False ):
    out = []
    for d in 0,1:
      out.append( directionNames[ d ] + ':' ) # "Across" or "Down"
      for sp in I.spots[ d ]:
	if showLen:
	  out.append("  %2d. %s (%d)" % \
		( sp.numb , showContentSpot( I.cellContent , sp ) , len ( sp ) ) )
	else:
	  out.append( "  %2d. %s " % \
		( sp.numb , showContentSpot( I.cellContent , sp ) ) )
    return out

  def shortListReport( I , n , cont , maxW = 84 ):
    """Produce lines of text displaying up to maxW of the
    n words listed in cont (should have n==len(cont))"""
    wpl = 84 / ( len( cont[ 0 ] ) + 5 )
    # trim number to display to 'reasonable' (depends on i)
    n1 = min( n , maxW )
    nrows = ( n1 - 1 ) / wpl + 1
    return [ ( ' '.join( [ "%3d:%s" % ( k + 1 , cont[ k ] )
	for k in range( j * wpl , min( ( j + 1 ) * wpl , n ) ) ] ) )
	    for j in range( nrows ) ]
      
    
  def report( I , verbose = 0 ):
    # Return report on current status, as list of lines
    out = []
    if verbose > 1:
      out += I.to_lines( )
    if I.contradiction:
      out.append( "Contradiction at %s : %s " % I.contradiction )
      return out
    if verbose:
      out += ( I.spotReport( True ) )
    # Sort spot-list with most restricted first
    shortList1 = [ ( n , sp ) for ( sp , n ) in I.liveSpots.items() ]
    shortList1.sort()
    I.shortList = [ ( i + 1 , sp , n , list ( I.spotContent[ sp ] ) ) 
	for ( i , ( n , sp ) ) in enumerate( shortList1[ : 8 ] ) ]
    for ( i , sp , n , cont ) in I.shortList[ :: -1 ]:
      if n!= len( cont ):
	print i, sp, n , len( cont ) , I.contradiction
      assert n == len( cont )
      out.append( " # %2d : %s : %d ..." % ( i , sp , n ) )
      # trim number to display to 'reasonable' (depends on i)
      out += I.shortListReport( n , cont , 
		( 984 , 84,40,20,16 , 12,10,8,7 , 6,5,5,4 )[ i ] )	       
    return out

def remark( s , i = 1 ):
  if debug > i: print s
  
def rem( s ):
  remark( s , 2 )


def main(args):
  global debug , allowRepeats , allowUpper , interactive , autofill
  # Flag description format :
  #	( short , long , arg , ... , arg , descn )
  #  so the length of the tuple (minus three) indicates number of args

  possFlags = [ 
    ( "-" , "end-flags" , "end flags - following args are filenames" ) ,
    ( "h" , "help" , "show help and exit" ) ,
    ( "f" , "fill" , "autofill the grid" ) ,
    ( "r" , "repeats" , "allow repeated words" ) ,
    ( "c" , "case" , "DISALLOW words with upper case" ) ,
    ( "q" , "quiet" , "print no progress info" ) ,
    ( "v" , "verbose" , "print extra progress info" ) ,
    ( "i" , "interact" , "prompt user for choice of words" )
    ]
  files = [ ]
  liveFlags = { }
  la = len( args )
  #if "--" in args:
    #la = args.index( "--" )
  for flag in possFlags:
    for flagS in ( '-' + flag[ 0 ] , '--' + flag[ 1 ] ):
      while flagS in args[ : la ]:
	i = args.index( flagS )
	# Mark end of flags if apt
	if flag[ 0 ] == '-':  la = i
	# arguments for the flag are immediately after it
	l = len( flag ) - 3
	liveFlags[ flag[ 0 ] ] = ( l and args[ i + 1 : i + 1 + l ] ) or True
	# remove flag and args
	args[ i : i + 1 + l ] = [ ]
  if "h" in liveFlags:
    print "Usage :   xwd  [options] file/s"
    print '\n'.join( [ "   -%s , --%-12s %s %s" % ( flag[ 0 ] , flag[ 1 ] ,
	         ' '.join( [ "<%s>" % a for a in flag[ 2 : -1 ] ] ) , flag[ -1 ] )
			for flag in possFlags ] )
    #print "Flags: \n-fill  autofill grid\n-v     verbose\n-q     quiet\n-r     allow repeated words"
    return
  autofill      =  ( "f" in liveFlags )
  allowRepeats  =  ( "r" in liveFlags )
  allowUpper = ( not "c" in liveFlags )
  debug      = 1 + ( "v" in liveFlags ) - ( "q" in liveFlags )
  interactive   =  ( "i" in liveFlags )
  
  for f in args[ 1 : ]:
    doFile( f )

def doFile( f ):
  if debug > 1: print "Reading source file '%s'..." % f
  it = xwd( f )  # lines )
  if autofill:
    if it.contradiction:
      return
    else:
      it.tryToFill( )
      if it.contradiction:
	return
  print
  print '\n'.join( it.to_lines() )
  print '\n'.join( it.report( 1 ) )
  if it.contradiction:
    return
  if interactive:
    print " Enter <spot number>,<word number> to commit a word."
    print "q = quit, b = back,  <spot number> to see full list."
    going = True
    while going:
      # ask the user what to do
      prompt = ":"
      cmd = raw_input( prompt )
      sp , w = None , None
      if cmd == 'q':
	going = False
	continue
      elif cmd == 'b':
	it.undoLastCull()
      else:
	try: 
	  if ',' in cmd:
	    sp , w = map( int , cmd.split( ',' ) )
	  else:
	    sp = int( cmd )
	except:
	  print "Invalid command - use 'q' to quit, or use number(s)"
	  continue
	if sp:
	  if 0 < sp <= len( it.shortList ):
	    i , sp , n , cont = it.shortList[ sp - 1 ]
	  else:
	    print "Spot number out of range - only %d available." \
		    % len( it.shortList )
	    continue
	  if w:
	    if 0 < w <= n:
	      w = cont[ w - 1 ]
	    else:
	      print "Word number out of range - %s had only %d available." \
		      % ( sp , n )
	      continue
	    it.fullPosit( sp , w )
	  else:
	    # spot only entered - show full list
	    print '\n'.join( it.shortListReport( n , cont , 984 ) )
	    continue
      print '\n'.join( it.to_lines() )
      print '\n'.join( it.report( 1 ) )



if __name__ == "__main__":
  main(list(sys.argv))
  pass
else:
  # while testing
  #global x,debug
  debug = 1
  x = xwd('x')

