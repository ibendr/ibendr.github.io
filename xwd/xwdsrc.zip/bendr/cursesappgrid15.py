#!/usr/bin/python

"""
A test application using the cursesapp architecture.

Target data type is a 15x15 grid of text characters,
but in this early example, we just use list instead of defining a class.

The functions strListSetChar , strListSetSlice are introduced
as operations on the grid - they would normally be methods
of a custom defined class.
"""

from cursesapp import *
#from curseslines import *

#global it  # the instance of the application - really just a debug convenience

global gridSize
gridSize = 15

def strListSetChar( l , y , x , c ):
  l[ y ] = l[ y ][ : x  ] + c + l[ y ][ x + 1 : ]

def strListSetSlice( l , y , x0 , x1 , s ):
  l[ y ] = l[ y ][ : x0 ] + s + l[ y ][ x1 : ]

class grid15( cursesApp ):
  appClass = list
  winBorderArgs = ( )   # ( '(',')','~','~','@','@','@','@' )
  cursor = None
  win = None
  def __init__( self , wind ):
    global gridSize
    #self.win = wind
    scrsize = gridSize + self.winOffset * 2
    self.scr = wind.subwin( scrsize , scrsize , 2 , 2 )
    self.scr.box()
    self.cursor = scrsize >> 1 , scrsize >> 1
  def _to_lines( self ):
    return self.loaded_object
  def subpoll( self , k ):
    if 32 <= k < 125:
      obj , ( y , x ) = self.loaded_object , self.cursor
      if obj:
	# change object!
	row = obj[ y ]
	if x < len ( row ):
	  # easy case
	  old = row[ x ]
	  # setup a change chain - pairs of  ( do ,  undo )
	  change = ( (   ( strListSetChar , y , x , chr( k ) ) , 
			 ( strListSetChar , y , x ,   old    )    ) , )
	else:
	  # this time have to append some spaces and the new letter
	  x0 , x1 , dx = len( row ), x + 1 , x - len( row )
	  change = ( (   ( strListSetSlice , y , x0 , x1 , dx * " " + chr( k ) ) ,
			 ( strListSetSlice , y , x0 , x1 , ""                  )   ) , )
	self.doChange( change )
	self._cmd_Move( )
	self.refresh()
	return True
	
  def _cmd_Move( self , dirn = 0 ):
    global gridSize
    out = list( self.cursor )
    ax , dn = 1 - ( dirn & 1 ) , dirn & 2
    out[ ax ] += 1 - ( dn )
    if ( dn ):
      # backward - check left / top i.e. zero
      while out[ ax ] < 0:
	out[ ax ] = gridSize - 1
	# and also move vertically IF we were moving horizontally
	if ax:
	  ax = 0
	  out[ ax ] -= 1
	  # and the while loop then checks for vertical wraparound
    else:
      while out[ ax ] >= gridSize:
	out[ ax ] = 0
	# and also move vertically IF we were moving horizontally
	if ax:
	  ax = 0
	  out[ ax ] += 1
	  # and the while loop then checks for vertical wraparound
    self.cursor = tuple( out )
    self.refresh()

  def refresh( self , total = False ):
    # taken from earlier trial - cursegrid.py
    it , scr = self.loaded_object , self.scr
    if scr:
      if total:
	self.refreshFrame( )
      if it:
	for y,row in enumerate( it[ : 15 ] ):
	  for x,c in enumerate( row[ : 15 ] ):
	    scr.addch( self.winOffset + y , self.winOffset + x , c )
      if self.cursor:
	scr.move( self.winOffset + self.cursor[ 0 ] ,
		  self.winOffset + self.cursor[ 1 ]  )
	scr.cursyncup()
      scr.refresh()
      #cursLineRefresh( self.win )

def main( wind , *args ):
  #global it , win
  crs.raw() # Should only be used when we are confident we can arrange exit
	      # since we lose the interception of ctrl-C
  crs.def_prog_mode()  # protect setting from changes by other processes
  it = grid15( wind )
  if len( args ) > 1:
    # try and load a file
    it._load_file( args[ 1 ] )
    #it.refresh()
  # crude loop
  ret = 0
  
  #cursLineFrame( wind , ( 10 , 10 ) , ( 25 , 40 ) ) 
  #cursLine( wind , 12 , 20 , -1 , 80 , 25 , -1 ) 
  #cursLineFrame( wind , ( 2 , 2 ) , ( 18 , 18 ) ) 
  #cursLine( wind ,  6 , 20 , 14 , -1 , -1 , 30 , 2 ) 
  
  while not ret:
    it.inner_loop()
    ret = it.poll()
  return ( ret , cursLineReport( wind ) )

if __name__ == "__main__":
  ret , rep = crs.wrapper( main , *sys.argv )
  #print ret
  #print rep