#!/usr/bin/python

import sys , subprocess , re

"""
Version 2 - many improvements...
  - using subprocess module for system calls (grep)
  - more structure
  - single-collision crossword checking
Version 3 -
  - read from file, no longer using grep
  - labelling of head-cells and spots
Version 4
  - removed obsolete code
  - introduce crossword class		\
  - break up and better structure code	/  both postponed for now
Version 5
  - switch to using regular expressions for much faster execution
  - use of zip command to speed up checking of possible letters in spots
  - improved comments - added remark() but not yet used
  - used more efficient code by assuming capitals only throughout
  - enabled reporting of shortest lists of live cells, and of CONTRADICTION
"""

# Parameters

debug = 3
keepSingletons = False

# Constants

directionNames = "Across" , "Down"

matchesPending = [] ; collisions = []
fileRoot = "words-len-"
lenLimit = 19

# Various characters of significance

ABC = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
abc = ABC.lower()

cAlphas = ABC + abc

# characters used to denote live cells (input and output),
# and number of possibile letters (as output)
cWilds = "123456789;;;;::::,,,,.... "

cClash = '*'
cBlock = '+'

cCells = cAlphas + cWilds + cClash

cEnds = "|#/\\<>"  # characters denoting end of line of crossword (comments etc. may follow)

# cell and spot classes are structural info only - content or possible content elsewhere

class cell:
  # A cell is a square of the crossword ( in which one letter / character is entered )
  # These are class default values,  and illustrative of format
  pos = ( 0 , 0 )	# position on grid
  spots = ( )		# A tuple ( sp , n ) for each spot it is part of ...
			#  sp is pointer to spot and n its position ( index ) in that spot
  def __init__( I , i , j ):
    I.pos = ( i , j )
  def __repr__( I ):
    # Print row first for correct ordering
    return ABC[ I.pos[ 1 ] ] + abc[ I.pos[ 0 ] ]

class spot:
  # A spot is a sequence of cells - ( in which a word is entered )
  # This class does NOT record the direction or label number of a spot - just the cells
  cells = ( )	# The cells of the spot - default value of none should never be used
  def __len__( I ):
    # length of spot is how many cells in it - hence equal to length of word required
    return len( I.cells )
  def __repr__( I ):
    # just string together the cell representations
    return '-'.join( [ c.__repr__() for c in I.cells ] )

# Stuff to deal with "content" - a set of possible values of a cell, with scores attached

def regExpContentC( cont ):
  # make a chunk of regular expression based on options for content
  ## we allow upper and lower case - the letter indicated in cont should always be upper
  #return '[' + ''.join( [ c[0].upper() + c[0].lower() for c in cont ] )  + ']'
  # since v4 all word lists are imported as upper and we just work in upper
  poss = ''.join( list( cont ) )
  if len( poss ) == 1:
    return poss
  else:
    return '[' + poss + ']'
def regExpContentW( sp , cont ):
  # make the full regular expression for the possibilities for a spot
  # cellContent object has to be passed as cont since it is not global
  return ''.join( [ regExpContentC( cont[ cl ] ) for cl in sp.cells ] )

def showContent( cont ):
  # What to display ( in one character ) for a given set of possibilities
  # cont is a set of [ letter , ... ] lists 
  l = len( cont )
  if l == 0:	return cClash
  if l == 1:	return list( cont )[ 0 ][ 0 ]
  if l > 26: l = 26
  return cWilds[ l - 1 ]

def showLabel( lbl ):
  return directionNames[ lbl[ 0 ] ] + ' ' + str( lbl[ 1 ] )

def main(*args):
  for f in args[1:]:
    if debug>1: print "Reading source file '%s'..." % f
    lines = file(f).read().split('\n')    
    main_inner( * lines )

def main_inner( * lines ):
  if debug >=3: print lines
  
  # The following 'globals' should become part of crossword class
  
  cells = [ ]
  spots = [ [ ] , [ ] ]		# Across and down spots - lists of pointers to cells
  
  cellLabels = dict()	# Number / label in cell
  spotLabels = dict()	# ( d , n ) where d is direction: 0 Across, 1 Down
			#	      and n is label in head cell (usually number)
  
  spotNowAcc = None	# Current 'across' spot
  spotsNowDn = dict()	# Current 'down' spots for each column
  
  cellContent = dict()	# Possible content for the cells, as sets of possibilities
			# After processing -
			# dictionary from cell (ptr) to a set of of permitted letters
			#  .... dict of letter -> [ n0 , n1 ] lists
			# where letter is a letter which could go in the cell, and
			# n0 , n1  are the number of words currently permissible (in
			# the across and down spots respectively) which agree with
			# this letter assignment;  one for unused direction.  (Zero
			# should not occur 'naturally' or else letter not in set
			# At input stage - 
			# dictionary from cell(ptr) to string (content) or number (priority)
  cellScores = dict()	# Number of live possibilities for each cell;  after processing -
			#   cellScores[ cell ] == len( cellContent[ cell ] )
  spotContent = dict()	# Possible content for the spots, as lists of words
  spotScores = dict()	# spot -> list of dicts : letter -> # of words containing
  spotRegExps = dict()  # regular expressions for each spot

  if debug>1: print "Establishing crossword structure..."

  # On the fly building of Across and Down spots ...
  #	... a little tricky - reading cells in rows, at any given time only one 'live'
  #		Across clue but several Down clues. Initially we allow spots of length 1.
  for j,line in enumerate( lines ):
    for i,c in enumerate( line ):
      if c in cEnds:
	# end of line - ignore following
	break
      else:
	if c in cCells:
	  # cell of crossword
	  #content = c.upper()
	  newCell = cell( i , j )
	  if not spotNowAcc:
	    spotNowAcc = spot()
	    spots[ 0 ].append( spotNowAcc )
	  if not i in spotsNowDn:
	    spotsNowDn[ i ] = spot()
	    spots[ 1 ].append( spotsNowDn[ i ] )
	  cells.append( newCell )
	  spotNowAcc.cells += ( newCell, )
	  spotsNowDn[ i ].cells += ( newCell, )
	  if c in cAlphas:
	    cellContent[ newCell ] = set( [ c.upper() ] )
	    n = 1
	  else:
	    # Wildcard ... have to allow everything at first
	    cellContent[ newCell ] = set( ABC )   # can only populate later
	    n = cWilds.find( c ) + 1	#  n == 0  means  c == cClash
	  cellScores[ newCell ] = n
	else:
	  # assume block - could check == cBlock if requiring strict adherence
	  # Close current spots - remove from list if too short (now defered)
	  if spotNowAcc:
	    spotNowAcc = None
	  if i in spotsNowDn:
	    del spotsNowDn[ i ]
    # End of the line - finish off current across spot 
    if spotNowAcc:
      spotNowAcc = None
  # End of file
  # Cull out any singleton spots and assign remaining spots to cells
  for d in 0,1:
    # Must use a ( slice ) copy of spots list because we are culling from original list
    for sp in spots[ d ][ : ]:
      if keepSingletons or len( sp ) > 1:
	for i,cl in enumerate( sp.cells ):
	  cl.spots += ( ( sp , i ) , )
      else:
	spots[ d ].remove( sp )
  # This will sometimes be convenient - and costs very little memory
  allSpots = spots[ 0 ] + spots[ 1 ]
  # Only after culling of singletons do we do cell and spot labels...
  headCells = list( set( [ sp.cells[ 0 ] for sp in allSpots ] ) )
  headCells.sort( None , repr )	# Sorts alphabetically with our Ce notation and hence
				# in correct order of grid appearance
  for i,cl in enumerate( headCells ):
    cellLabels[ cl ] = i + 1
  for d in 0,1:
    for sp in spots[ d ]:
      spotLabels[ sp ] = ( d , cellLabels[ sp.cells[ 0 ] ] )

  if debug>1: print "Fetching word lists..."

  # Fetch all relevant word lists
  lengths = set( [ len( sp ) for sp in allSpots ] )	# all lengths
  wordLists = dict( [ \
    ( l , [ w.upper() for w in file( fileRoot + str( l ) ).read().split() ] ) \
	  for l in lengths ] )
  # And assign sublists according to restrictions

  if debug>1: print "Selecting compatible words and refining cell restrictions..."
  liveSpots = dict()	# spot : n    where n is number of possibilities left
  spotsToAdjust = set( allSpots )
  for d in 0,1:
    for sp in spots[ d ]:
      if debug>2: print "   %s ... " % showLabel( spotLabels[ sp ] )
      regExp = regExpContentW( sp , cellContent )
      spotRegExps[ sp ] = regExp
      if len( sp ) == len( regExp ):
	# forced word - nothing to do. (And now we don't check for being in list.)
	newList = [ regExp ]
      else:
	regExpComp = re.compile( regExp )
        newList = [ w.upper() for w in wordLists[ len( sp ) ] if regExpComp.match( w.upper() ) ]
        if len( newList ) > 1:
	  liveSpots[ sp ] = len( newList )
	else:
	  if not newList:
	    print "CONTRADICTION"
	    return
      transpose = zip( * newList )
      spotContent[ sp ] = newList
      spotScores[ sp ] = [ dict( [ ( l , column.count( l ) ) for l in ABC if l in column ] )
			  for column in transpose ]
      if debug>2: print "             ... and cells ... "
      # Check each cell of spot for currently permissible letters
      for i,cl in enumerate( sp.cells ):
	change = False
	for c in list( cellContent[ cl ] ):
	  if c not in spotScores[ sp ][ i ]:
	    # No words with this letter - cull it!
	    cellContent[ cl ].remove( c )
	    change = True
	# If any changes to this cell, flag other spot(s) it's in
	if change:
	  cellScores[ cl ] = len( cellContent[ cl ] )
	  for ( sp1, i1 ) in cl.spots:
	    if not sp1 == sp:
	      spotsToAdjust.add( sp1 )
      # Mark this spot as now done... although it may get undone before we are through
      if sp in spotsToAdjust:
	spotsToAdjust.remove( sp )
  # Now the repeating section of the process...
  while spotsToAdjust:
    if debug>1: print "Further restricting %d spots" % len( spotsToAdjust )
    if debug > 3:
      #print spots
      for d in 0,1:
	print directionNames[ d ] + ':'		# "Across" or "Down"
	for sp in spots[ d ]:
	  print "  %2d. %s " % ( spotLabels[ sp ][ 1 ] , \
	      ''.join( [ showContent( cellContent[ c ] ) for c in sp.cells ] ) )
    for sp in list( spotsToAdjust ):
      if debug>2: print showLabel( spotLabels[ sp ] )
      # Update the regular expression
      regExp = regExpContentW( sp , cellContent )
      spotRegExps[ sp ] = regExp
      if len( sp ) == len( regExp ):
	# forced word - nothing to do. (And now we don't check for being in list.)
	newList = [ regExp ]
      else:
	regExpComp = re.compile( regExp )
        newList = [ w for w in spotContent[ sp ][ : ] if regExpComp.match( w ) ]
      if not newList:
	# Contradiction reached as no words left for this spot
	# We need an exemption here so we can dictate exceptional words by putting them
	# in the input, and workarounds like forcing phrases until they're implemented
	# ...( done? )
	print "CONTRADICTION"
	return
	#pass
      liveSpots[ sp ] = len( newList )
      if len( newList ) == 1:
	del liveSpots[ sp ]
      spotContent[ sp ] = newList
      transpose = zip( * newList )
      newSpotScores = [ dict( [ ( l , column.count( l ) ) for l in ABC if l in column ] )
			  for column in transpose ]
      spotScores[ sp ] = newSpotScores
      for i,cl in enumerate( sp.cells ):
	if len( newSpotScores[ i ] ) < len( spotScores[ sp ][ i ] ):
	  # Less permitted letters in this cell...
	  for c in list( cellContent[ cl ] ):
	    if c not in newSpotScores[ i ]:
	      # No words with this letter - cull it!
	      cellContent[ cl ].remove( c )
	  # Flag other spot(s) it's in
	  cellScores[ cl ] = len( cellContent[ cl ] )
	  for ( sp1, i1 ) in cl.spots:
	    if not sp1 == sp:
	      spotsToAdjust.add( sp1 )
      # Mark this spot as done
      spotsToAdjust.remove( sp )
	
  if debug > 1:
    print spots
    for d in 0,1:
      print directionNames[ d ] + ":"
      for sp in spots[ d ]:
	  print "  %2d. %s " % ( spotLabels[ sp ][ 1 ] , \
	      ''.join( [ showContent( cellContent[ c ] ) for c in sp.cells ] ) )
    print cells[ 1 ].spots
    print wordLists[ 10 ][ 123 ]
  # Report shortest list of words for a live spot
  shortList = [ ( n , sp ) for ( sp , n ) in liveSpots.items() if n > 1 and n < 64 ]
  shortList.sort()
  #hotSpot = shortList[ 0 ]
  for hotSpot in shortList[ : 5 ]:
    #print hotSpot
    print "%3d words for %s %s..." % ( hotSpot[ 0 ] , spotLabels[ hotSpot[ 1 ] ][ 1 ] ,
				      directionNames[ spotLabels[ hotSpot[ 1 ] ][ 0 ] ] )
    sC = spotContent[ hotSpot[ 1 ] ]
    if len( sC ) < 50:
      print sC
    else:
      print len( sC )
    

def redoCollisions( lists ):
  changed = set() ; done = False
  while not done:
    for coll in collisions:
      if coll[ 1 ]:
	if debug > 2: print coll
	# Set of possibilities has been restricted
	coll[ 1 ] = False # Although it may become true again before we are done
	allowed = set( coll[ 0 ] ) # duplicate set - unnecessary at this stage
	for ( n , i ) in ( coll[ 2 : 4 ] , coll[ 4 : 6 ] ):
	  lst = lists[ n ]
	  newList = [ w for w in lst if w[ i ] in allowed ]
	  if not newList:
	    # Contradiction reached - wipe everything and return
	    lists[:] = [[] for l in lists]
	    return
	  if len( newList ) < len( lst ):
	    # update list and flag as changed
	    changed.add( n )
	    lists[ n ] = newList
	    # Check if other collisions involved with this list
	    for coll1 in collisions:
	      if not coll1 is coll:
		i1 = -1
		if n == coll1[ 2 ]:  i1 = coll1[ 3 ]
		if n == coll1[ 4 ]:  i1 = coll1[ 5 ]
		if i1 > -1:
		  # make a new list
		  allowed1 = coll1[ 0 ]
		  newAllowed = set( [ w[ i1 ] for w in newList ] )
		  newAllowed = allowed1.intersection( newAllowed )
		  # update and flag if changed
		  if len( newAllowed ) < len( allowed1 ):
		    coll1[ 0 ] = newAllowed
		    coll1[ 1 ] = True
    if changed:
      if debug>2: print changed
      changed = set()
    else: done = True
    
def remark( s , i = 1 ):
  if debug > i: print s
  
def rem( s ):
  remark( s , 2 )

if __name__ == "__main__":
    main(*sys.argv)