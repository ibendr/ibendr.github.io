#!/usr/bin/python

"""
Crossword setting interface built on cursesapp and xwd

code reworked from an5
"""

#import sys , subprocess , re

from cursesapp import *
from curseslines import *
from xwd import *



# For testing purposes

global use_curses
use_curses = True


class cursesAppXwd( cursesApp ):
  appClass = xwd
  cursor   = None
  winBorderArgs = None   # we'll use cursLineFrame instead
  winPadding = 2
  
  #def __init__( I , wind ):
    #I.win = wind
  #def _from_lines( I , lines ):
    #return xwd( lines )
  def _to_lines( I ):
    # note that we only save the current grid and fill, not 
    # any information about current analysis
    return ( I.loaded_object and I.loaded_object.to_lines() )
  def subpoll( I , k ):
    if 32 <= k < 125:
      obj , ( y , x ) = I.loaded_object , I.cursor
      if obj:
	pass
  #def _cmd_Move( I , dirn = 0 ):
    #global gridSize
    #out = list( I.cursor )
    #ax , dn = 1 - ( dirn & 1 ) , dirn & 2
    #out[ ax ] += 1 - ( dn )
    #if ( dn ):
      ## backward - check left / top i.e. zero
      #while out[ ax ] < 0:
	#out[ ax ] = gridSize - 1
	## and also move vertically IF we were moving horizontally
	#if ax:
	  #ax = 0
	  #out[ ax ] -= 1
	  ## and the while loop then checks for vertical wraparound
    #else:
      #while out[ ax ] >= gridSize:
	#out[ ax ] = 0
	## and also move vertically IF we were moving horizontally
	#if ax:
	  #ax = 0
	  #out[ ax ] += 1
	  ## and the while loop then checks for vertical wraparound
    #I.cursor = tuple( out )
    #I.refresh()
  def init_view( I ):
    # called when new object loaded
    #I.win.clear()
    it = I.loaded_object
    if it:
      cursLineClear( I.win )
      cursLineFrame( I.win )
      cursLine( I.win , 0 , it.width  + 2 * I.winPadding - 1 , 
			    it.height + 2 * I.winPadding - 1 , - 1 , - 1 , 0 )

  def refresh( I , total = False ):
    # taken from earlier trial - cursegrid.py
    it = I.loaded_object
    if it:
      if total:
	cursLineRefresh( I.win )
	I.refreshFrame( )
      if it:
	lines = it.to_lines( )
	for y,row in enumerate( lines ):
	  I.win.addstr( I.winOffset + y , I.winOffset , row[ : - 1 ]  )
      if I.cursor:
	I.win.move( I.winOffset + I.cursor[ 0 ] ,
		  I.winOffset + I.cursor[ 1 ]  )
	I.win.cursyncup()
      I.win.refresh()

def xwd_report( I ):
  #The original text-based output of an5
  if debug:
    #print spots
    for d in 0,1:
      print directionNames[ d ] + ":"
      for sp in I.spots[ d ]:
	  print "  %2d. %s (%d)" % ( I.spotLabels[ sp ][ 1 ] , \
	      ''.join( [ showContent( I.cellContent[ c ] ) for c in sp.cells ] ) , \
		len( sp ) )
  # Report shortest list of words for a live spot
  shortList = [ ( n , sp ) for ( sp , n ) in I.liveSpots.items() if n > 1 and n < 1024 ]
  shortList.sort()
  #hotSpot = shortList[ 0 ]
  for hotSpot in shortList[ : 8 ]:
    #print hotSpot
    print "%3d words for %s %s..." % ( hotSpot[ 0 ] , I.spotLabels[ hotSpot[ 1 ] ][ 1 ] ,
				      directionNames[ I.spotLabels[ hotSpot[ 1 ] ][ 0 ] ] )
    sC = I.spotContent[ hotSpot[ 1 ] ]
    lsc = len( sC )
    if lsc < 50 or hotSpot == shortList[ 0 ]:
      print '\t'.join( sC )
    else:
      print '...\t%s\t...' % '\t'.join( sC[ lsc/2 - 24 : lsc/2 + 24 ] )
    
def plainMain(*args):
  for f in args[1:]:
    if debug>1: print "Reading source file '%s'..." % f
    lines = file(f).read().split('\n')    
    it = xwd( )
    it.from_lines( lines )
    it.analyse( )
    xwd_report ( it )

def main( wind , *args ):
  #global it , win
  crs.raw() # Should only be used when we are confident we can arrange exit
	      # since we lose the interception of ctrl-C
  crs.def_prog_mode()  # protect setting from changes by other processes
  it = cursesAppXwd( wind )
  if len( args ) > 1:
    # try and load a file
    it._load_file( args[ 1 ] )
    #it.refresh()
  # crude loop
  ret = 0
  while not ret:
    it.inner_loop()
    ret = it.poll()
  return ( ret , cursLineReport( wind ) )

if __name__ == "__main__":
  #global use_curses
  global settings
  import args as parseArgs
  xwd.settings = xwd.getSettings( list ( sys.argv ) )
  if use_curses:
    ret = crs.wrapper( main , * sys.argv )
  else:
    ret = plainMain ( * sys.argv )
  print ret