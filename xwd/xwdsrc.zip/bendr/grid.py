#!/usr/bin/python

"""
A (fairly) trivial module for testing structures,
in particular separation of content and interface.
"""
class gridRow( list ):
  """Row of a grid"""
  def __init__( self , parent , index , length , c_init = " " ):
    list.__init__( self , length * c_init )
    self.parent = parent
    self.index  = index
  # override assign to do some other thing also
  def __setitem__( self , x , c ):
    for func in self.parent.onEdit:
      if func( self.parent , ( self.index , x ) , c , self[ x ] ):
	return
    list.__setitem__( self , x , c )

class grid( list ):
  """A grid is a rectangular array of cells possibly containing characters,
  as a list of rows. """
  # events to call when edit requested
  # should be functions whose arguments are  grid , ( y , x ) , new_v , old_v
  # and they should return True to stop bubbling AND avoid assignment
  onEdit = [ ]
  size = 0,0
  def __init__( self , ys , xs , c_init = " " ):
    # initialised with height, width. Starts full of spaces
    list.__init__( self , [ gridRow( self , y , xs , c_init )
			      for y in range(ys) ] )
    self.size = ys,xs
  # override assign to use pair assignment i.e. grid[ 3,4 ] = "e"
  # which conveniently also rules out replacing rows e.g. grid[ 3 ] = ...
  def __setitem__( self , yx , c ):
    for func in self.onEdit:
      if func( self , yx , c , self[ x ] ):
	return
    list.__setitem__( self[ yx[ 0 ] ] , yx[ 1 ] , c )



  