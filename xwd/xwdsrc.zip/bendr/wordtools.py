# load word list
ws = file( "words" ).read().split()

# Make lists by length - for faster access
# we could use a list constructor as follows
#       wl = [ [ w for w in ws if len( w ) == l ] for l in range(20) ]
# but that would mean 24 passes over the full list, not one
# Instead, for each word, add to list for its length
wl = [ [ ] for l in range( 24 ) ]
for w in ws:
    wl[ len( w ) ].append( w )

# single list, alphabetic order
wsa = sorted( ws )

# single list in length order
wsl = reduce( list.__add__ , wl )

# function to get lists starting with particular letter, of given length
wcl = lambda c , l : [ w for w in wl[ l ] if w[ 0 ].upper( ) == c.upper( ) ]

# test if in list - much quicker than ( w in ws ) because only looks in length-specific list
def inWs( w ):
    return w in wl[ len( w ) ]

# sub-anagram test - see if w's letters are all in x (enough times)
def subAn( w , x ):
    # short version, which may be just as quick
    for c in set( w ):
        if w.count( c ) > x.count( c ):
            return False
    return True
def subLetters( w , x ):
    # return letters of x minus letters of w
    # will raise exception if w not a sub-anagram of x
    l , m = list( w ) , list( x )
    for c in l:
        # could put in try-except block, but the exception
        # raised when c not in m is perfectly appropriate.
        m.remove( c )
    return ''.join( sorted( m ) )

def supAns( w ):
    # return all super-anagrams of w and the remaining letters
    return [ ( w1 , subLetters( w , w1 ) ) for w1 in ws \
                  if len( w1 ) > len( w ) and subAn( w , w1 ) ]

def ans( w ):
    # return all anagrams of a word - ignoring case
    w0 = w.lower( )
    return [ w1 for w1 in wl[ len( w ) ] if subAn( w0 , w1.lower() ) ]
    
def supAnsA( w ):
    # return all super-anagrams of w where remainder can be one word
    # NOT YET IMPLEMENTED
    pass

def compWords( w ):
    # return list of words consisting of w plus another word
    # although w itself needn't be a word
    l = len( w )
    return [ w1 for w1 in ws if w1[ : l ] == w and inWs( w1[ l : ] ) ]
