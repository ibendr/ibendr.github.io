print __name__
