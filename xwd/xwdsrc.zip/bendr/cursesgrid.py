#!/usr/bin/python

"""
A (fairly) trivial module for testing structures,
in particular separation of content and interface.
"""

import sys
import grid   as grd
import curses as crs

win = None
scr = None
it  = None
cursor = None

def _grid_display( self , yd = 1 , xd = 1 ):
  global cursor
  if scr:
    for y,row in enumerate( self ):
      for x,c in enumerate( row ):
	scr.addch( yd + y , xd + x , c )
    if cursor:
      scr.move( yd + cursor[ 0 ] , xd + cursor[ 1 ]  )
      scr.cursyncup()
    scr.refresh()
grd.grid.display = _grid_display

def redraw():
  # redraw everything - e.g. after a dialog box has taken over screen
  if win:
    win.clear()
    #win.box()
    if scr:
      scr.box()
    if it:
      it.display()

def moveCursor( dirn = 0 ):
  # returns new yx value from old and movement direction (with wrap)
  # directions are  0 ->      1 v      2 <-     3 ^
  global cursor
  if not cursor:
    return
  out = list( cursor )
  ax , dn = 1 - ( dirn & 1 ) , dirn & 2
  out[ ax ] += 1 - ( dn )
  if ( dn ):
    # backward - check left / top i.e. zero
    #  If there is no grid we still check, but
    #    wrap around to a default width / height 8 (yes very arbitrary)
    while out[ ax ] < 0:
      out[ ax ] = ( ( it and it.size[ ax ] ) or 8 ) - 1
      # and also move vertically IF we were moving horizontally
      if ax:
	ax = 0
	out[ ax ] -= 1
	# and the while loop then checks for vertical wraparound
  else:
    # forward movement : only limit if there is a grid
    if it:
      while out[ ax ] >= ( ( it and it.size[ ax ] ) or 8 ):
	out[ ax ] = 0
	# and also move vertically IF we were moving horizontally
	if ax:
	  ax = 0
	  out[ ax ] += 1
	  # and the while loop then checks for vertical wraparound
  cursor = tuple( out )
  #return cursor
  
def getK():
  # wait for keypress and return it
  if win:
    kp = -1
    while kp == -1:
      kp = win.getch()
    return kp

def main( *args ):
  return crs.wrapper( main_inner , *args[1:] )

def main_inner( wind , ys = 4, xs = 8 , c_init = '+' , yd = 2 , xd = 2):
  global it , win , scr , cursor
  # we should get all our setting right and then save,
  #  although so far default ones seem good
  crs.raw() # Should only be used when we are confident we can arrange exit
	      # since we lose the interception of ctrl-C
  crs.def_prog_mode()  # protect setting from changes by other processes
  # initialise a grid and display it
  win = wind
  scr = win.subwin( ys + 2 , xs + 2 , yd , xd )
  it = grd.grid( ys , xs , c_init )
  cursor = 0,0
  #scr.clear()
  #scr.box()
  redraw()
  # set up a little loop
  ok = True
  #yx = 2,5
  while ok:
    #it.display( yx )
    k = getK()
    # now lets respond to keypresses
    if 32 <= k < 127:
      # printable character
      it[ cursor ] = chr( k )
      moveCursor( )
      it.display()
    elif 0x102 <= k < 0x106:
      # arrow key
      moveCursor( (1,3,2,0)[ k - 0x102 ] )
      it.display()
    elif k < 32:
      # control
      if   k == 19:
	# ^S
	pass
      elif k == 17 or k == 27:
	# ^Q  or  ESC	(but may use ESC for something else later)
	ok = False # quit loop
      elif k == 15:
	# ^O - open file
	import os
	os.system('dialog --stdout --fselect "" 20 60 > dialogtest')
	fn = file("dialogtest").read()
	crs.reset_prog_mode() # restore settings after changes by dialog
	#win.keypad(1)  # seemed to get switched off by dialog
	## the def_ and reset_ prog_mode() calls handle it better I think
	redraw()
	if fn:
	  win.addstr( 14 , 4 , "Opening file %s " % fn )
	  try:
	    inp = file( fn ).readlines()
	  except:
	    win.addstr( 15 , 4 , "Failed to open file" )
	    inp = None
	  if inp:
	    # update grid with data from lines in file
	    for y in range( it.size[ 0 ] ):
	      inpL = inp[ y ]
	      for x in range( min( it.size[ 1 ] , len( inpL ) ) ):
		# dare not use slices just now...
		it[ y,x ] = inpL[ x ]
	    it.display()
      else:
	win.addstr( 13 , 6 , hex( k ) )
    else:
      win.addstr( 12 , 6 , hex( k ) )
    # for now need ctrl-C to exit

if __name__ == "__main__":
    main(*sys.argv)
