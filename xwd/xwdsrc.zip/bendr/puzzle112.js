//testing backticks - ES6
xwdDo(`
=SOMELIKEITHOT=|
S=V=N=M= =H=R=M|
TREETOP=AMERICA|
E=R=E=R= =R=G=R|
EXTERIORS=A A I|
P=L===M===P=M=L|
LOYAL=PUBLICITY|
E===E=T=I= ===N|
CONTINUAL=  R M|
H= =T===I===E=O|
A   M=GENTLEMEN|
S= =O=R=G=A=O=R|
EPISTLE=UNDERGO|
S=E=I=E=A=E=S=E|
=PREFERBLONDES=|

Across:
   1. SOME LIKE IT HOT (4 4 2 3) He took limiest mix, said to include lemon, in the cast
  10. TREETOP (7) Potter about, putting energy into constructing part of canopy
  11. AMERICA (7) A crime organised by a country
  12. EXTERIORS (9) Surfaces at tree six or so
  13. A3A3I (5) ATARI Go attack a console!
  14. LOYAL (5) Member of ruling family swapped sides at first, but likely to remain true
  16. PUBLICITY (9) I pity club set ... the exposure!
  18. CONTINUAL (9) Not stopping with extreme caution before start of lap
  20. 25R3M (5) STRUM Holy spirit with some guitar action
  22. A443M (5) AXIOM Given a cricket team with a mantra...
  23,27. GENTLEMEN PREFER BLONDES (9 6 7) ...soft chaps would rather be at the fair, where 9 dn sings about diamonds
  25. EPISTLE (7) Corresponding longer recording is let out
  26. UNDERGO (7) Endure shaking ground all around the Earth
  27. see 23
Down:
   2. OVERTLY (7) Too accepting of time in the open
   3. ENTER (5) Green terraces provide instructive response to a rap
   4. IMPROMPTU (9) Unprepared, devil has to wrestle with familiar French address
   5. E4A3S (5) EXAMS Wild sex around about dawn led to medical checks
   6. THERAPIES (9) He parties wildly and then gets treatment
   7. ORIGAMI (7) Paper adapted by artist
   8. STEEPLECHASES (13) Harsh 12ac of late cash aids earless races
   9. MARILYN MONROE (7 6) Ploy Norman Mailer lost without pal featuring in 1 ac
  15. LEITMOTIF (9) Piece of music with dubious tie to film
  17. BILINGUAL (9) Lost gold billing due to having subtitles, perhaps
  19. N344IER (7) NOISIER More inquisitive about one who is not so peaceful
  21. REMORSE (7) It is shown to reduce penalties realting to the code
  23. GREER (5) Yes-man loses a writer
  24. LADEN (5) Supervillain puts bin out with a burden
`)