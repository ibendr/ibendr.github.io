#!/usr/bin/python

"""
A module giving the skeleton of a curses application.

Provides basic open , save , quit , help , redo , undo

Rather than having a main loop,  poll() should be called by the main application
at moments which are suitable for it,  e.g. at moments appropriate for 
interrupting a reiterative process (between iterations)
"""

import os , sys
import curses as crs

class cursesApp( object ):
  """Make a subclass of this as your application."""
  appClass        = None
  loaded_filename = None
  loaded_object   = None
  #quitting = False

  winBorderArgs   = ()        # default border ( use None for none )
  displayFilename = True      # put filename in middle of top row ( in frame )
  winPadding      = 1         # padding inside border
  winOffset       = 2         # will be computed for subclass at runtime

  history_changes = [ ]
  history_ptr = 0
  history_saved = 0

  hotkeys = {
     1 : "All Select" ,
     2 : "None Select" ,
     3 : "Copy Edit" ,
     4 : "Delete Edit" ,
    14 : "New File" , 
    15 : "Open File" ,
    17 : "Quit" ,
    18 : "Reload File" ,
    19 : "Save File" ,
    20 : "SaveTo File" ,
    22 : "Paste Edit" ,
    23 : "Close File" ,
    24 : "Cut Edit" ,
    25 : "Redo Edit" ,
    26 : "Undo Edit" ,
    27 : "Escape" ,
    0x102 : ( "Move" , 1 ) ,  #  v
    0x103 : ( "Move" , 3 ) ,  #  ^
    0x104 : ( "Move" , 2 ) ,  # <--
    0x105 : ( "Move" , 0 ) ,  # -->
    0x152 : ( "Move Page" , 0 ) ,
    0x153 : ( "Move Page" , 1 ) ,
    0x109 : "Help"
    }
  # These will be established for subclasses at runtime...
  hotkeyFuncs = None
  briefHelp = None
  # ... using this method
  @classmethod
  def _make_hotkey_func_list( cls ):
    # Make the classes hotkeyFuncs array if not already done
    clsDir = dir( cls )  
    clsNam = cls.__name__
    if not cls.hotkeyFuncs:
      cls.hotkeyFuncs = {}
      for key,fnam in cls.hotkeys.items():
	if isinstance ( fnam , str ):
	  nam , fargs = fnam , ()
	else:
	  nam , fargs = fnam[ 0 ], fnam[ 1 : ]
	name = "_cmd_" + nam.replace(' ','_')
	if name in clsDir:
	  # assign existing methods
	  cls.hotkeyFuncs[ key ] = ( getattr( cls , name ) , fargs )
      if not cls.briefHelp:
	# brief help is hotkey assignments with their original
	#   string descriptions where their actual methods exist
	cls.briefHelp = '\n'.join( [ "%s   :    %s " %
		( crs.keyname( k ) , cls.hotkeys[ k ] ) for k in cls.hotkeyFuncs ] )
      cls.winOffset = ( cls.winBorderArgs != None ) + cls.winPadding
  # The first time the app is instantiated, we work out the hotkey tables
  #  ( although it should only happen once anyway )
  def __new__( cls , wind ):
    #global it
    #global win
    cls._make_hotkey_func_list( )
    it = object.__new__( cls )
    it.win = wind
    return it

    # methods for subclasses to implement
    
  def __init__( I , wind ):
    I.win = wind
  def init_view( I ):
    """ Do any necessary setting up of the view after
    loading a new file."""
    pass
  def refresh( self , total = False ):
    """ Do such updating of the display as is appropriate.
    If total = True , redraw everything."""
    if total:
      self.win.clear()
      self.refreshFrame()
  def refreshFrame( self ):
    it , win = self.loaded_object , self.win
    if win:
      # do border, title etc.
      #win.clear()
      if self.winBorderArgs != None:
	win.border( * self.winBorderArgs )
      if self.displayFilename and self.loaded_filename:
	nam = self.loaded_filename
	ttlWid = max( 2 , win.getmaxyx( )[ 1 ] - 4 )
	lft = max( 2 , ( ttlWid - len( nam ) ) >> 1 )
	win.addstr( 0 , lft , nam[ - ttlWid : ] ) 
  def inner_loop( self ):
    # should return 0 (or False / None) to continue looping
    #  otherwise 'exit code'
    return "Code error: inner_loop not implemented by subclass of cursesApp"
  def subpoll( self , k ):
    # Respond to keycode k
    # should return True if used or exit code (!= True ) to break loop
    # return False / None if keycode was unused
    pass
  
  # Default methods for converting object to and from lines of text,
  #   for use in load and save operations.
  # Two approaches for subclasses available here -
  #  - override these as appropriate ( recommended )
  #  - leave these alone, and implement __str__ and __init__ accordingly
  def _to_lines( self ):
    """Convert loaded object to lines of text - for writing to file.
    Default: break string output into lines."""
    return str( self.loaded_object ).splitlines()
  def _from_lines( cls , lines ):
    """Create an object of the application's target class
    from lines of text - as read from source file.
    Default: pass them to the target class' initializer __init__."""
    return cls.appClass and cls.appClass( lines )
  
  def alert( self , s ):
    """ Put an alert message in a dialog messagebox """
    if self.win:
      sl = s.splitlines()
      maxyx = self.win.getmaxyx( )
      ys = min( len( sl ) + 5 , maxyx[ 0 ] - 2 )
      xs = min( max( map ( len , sl ) ) + 6 , maxyx[ 1 ] - 2 )
      self.dialog( '--msgbox "%s" %d %d' % ( s , ys , xs ) , True ) 
  def dialog( self , s , justExitCode = False ):
    """Run a dialog via os, with options in s
    and return the output as ( str , exit code )
    Use justExitCode if there is no need to retrieve the string."""
    if justExitCode:
      # easy - we return exit code not text
      out = os.system( 'dialog %s' % s )
    else:
      xcd = os.popen( 'dialog --stdout %s ; x=$? ; echo ; echo $x' % s ).read().splitlines();
      out = ( '\n'.join( xcd[ : -1 ] ) , xcd[ -1 ] )
    if self.win:
      crs.reset_prog_mode() # restore settings after changes by dialog
      self.win.clear()		# clear screen and redraw everything
      if self.loaded_object:
	self.refresh( True )
    return out
  
		# File functions

  def _load_file( self , fn ):
    if fn:
      #win.addstr( 14 , 4 , "Opening file %s " % fn )
      try:
	inp = file( fn ).read().splitlines()
      except:
	#win.addstr( 15 , 4 , "Failed to open file" )
	inp = None
      if inp:
	self.loaded_object   = self._from_lines( inp )
	if self.loaded_object:
	  self.loaded_filename = fn
	  self.history_changes = [ ]
	  self.history_ptr     =  0
	  self.history_saved   =  0
	  self.init_view( )
	  self.refresh( True )
	
  def _save_file( self , fn ):
    #win.addstr( 14 , 4 , "Opening file %s for saving  " % fn )
    try:
      fil = file( fn , "w" )
      fil.write( '\n'.join( self._to_lines() ) )
      fil.close ()
      self.loaded_filename = fn
      self.history_saved = self.history_ptr
    except:
      self.alert( "Failed to open file" )
  def _check_Saved( self ):
    """
    Return True if ok to go ahead and close / quit / etc.
    Alas we have no Yes/No/Cancel box so we can't offer
    to save from here - just query going ahead with unsaved close
    """
    #Easy case - we're saved up to date anyway
    if self.history_ptr == self.history_saved:
      return True
    # Otherwise check is user wants to do a save
    qry = self.dialog( '--yesno "Are you sure you wish to close\n\
	    %s without saving changes?" 12 80' % self.loaded_filename , True )
    return ( qry == 0 )


	# Command functions - method name is significant _cmd_ + ...
  
  def _cmd_Quit( self ):
    # Check for saving work
    if not self._cmd_Close_File( ):
      #self.quitting = True
      return "QUIT"
    else:
      return #"QUIT anyway"
  def _cmd_Help( self ):
    s = self.briefHelp
    if s:
      self.alert( s )
  def _cmd_Open_File( self ):
    if not self._cmd_Close_File( ):
      fn = self.dialog( '--fselect "" 20 60' )[ 0 ]
      self._load_file( fn )
  def _cmd_Close_File( self ):
    #returns True if close has failed - 
    # i.e. file still open (unsaved) and user Cancelled
    if not self.loaded_object:
      # Nothing to close - OK
      return None #True
    if self._check_Saved( ):
      # Unsaved but user OK
      # close displays etc.?
      self.loaded_filename = None
      self.loaded_object = None
      self.refresh( True )
      return False #True
    else:
      # Unsaved, cancelling close
      return True #False
  def _cmd_Save_File( self ):
    # Check if we have a filename to save back to
    if self.loaded_filename and self.loaded_object:
      # Check if any changes since save
      if self.history_ptr != self.history_saved:
	# OK, now save
	self._save_file( self.loaded_filename )
  def _cmd_SaveTo_File( self ):
    fn = self.dialog( '--fselect "" 20 60' )[ 0 ]
    if fn:
      if os.path.isfile( fn ):
	#return "exists"
	qry = self.dialog( '--yesno "The file %s already exists.\n \
		      Do you want to overwrite it?" 10 30' % fn , True )
	if qry:
	  return
      self._save_file( fn )
      self.refresh( True )

		# Edit history commands - redo and undo
		
	# These will eventually be separated to a history object (?)
  
  def _cmd_Redo_Edit( self ):
    # Can only do a redo if we're not at the end of the history
    if self.history_ptr < len( self.history_changes ):
      for change in self.history_changes[ self.history_ptr ]:
	change[ 0 ][ 0 ]( self.loaded_object , * change[ 0 ][ 1: ] )
      self.history_ptr += 1
      self.refresh()
  def _cmd_Undo_Edit( self ):
    # Can only do an undo if we're not at the start of the history
    if self.history_ptr > 0:
      self.history_ptr -= 1
      for change in self.history_changes[ self.history_ptr ][ :: -1 ]:
	change[ 1 ][ 0 ]( self.loaded_object , * change[ 1 ][ 1: ] )
      self.refresh()
  def doChange( self , change ):
    """Put a change on the history, replacing tail thereof,
     and execute the change"""
    # Dock tail of history
    self.history_changes[ self.history_ptr : ] = [ ]
    # Add change - will be pointed to as next redo, so can call redo
    self.history_changes.append( change )
    self._cmd_Redo_Edit( )

  # It should be OK to not override poll, but customise app with
  #  combination of adjusting hotkeys and subpoll()
  def poll ( self ):
    """
    Check for keypresses and call appropriate methods
    returning non-zero only if main loop should be interrupted
    """
    k = self.win.getch()
    if k != -1:
      self.win.addstr( 3 , 20 , "%s   %s    " % ( hex( k ) , crs.keyname( k ) ) )
    if k in self.hotkeyFuncs:
      func , fargs = self.hotkeyFuncs[ k ]
      return func( self , * fargs )
    else:
      # see if subclass has a use for the keycode
      kk = self.subpoll( k )
      if kk == True:
	return
      else:
	if kk:
	  return kk
	else:
	  # unknown keycode
	  #win.addstr( 4 , 30 , " Inactive keycode - %s   " % hex( k ) )
	  return
