#!/usr/bin/python

"""
Draw lines on a curses window using the special characters (as in bpxes).

For consistency, use frame( win ) in place of win.box() or win.border()

Currently, we don't check what's on the screen, although this is
possible with win.instr( y , x , n ) (we'd use n=1).

Hence, code will 'think' old lines are still there unless told
to forget them with cursLineClear.

So when calling win.clear() also call cursLineClear()

OR call cursLineRefresh() which will redraw all the current lines
"""

import curses as crs

global _lineData, _lineAscii, _lineLog, _lineIds
_lineData = { }
_lineIds = { }
_lineLog = [ ]

# Line data is a sort of bitfield for a window's lines.
# each text cell can have lines in any of 4 directions
# ( 0 >  1 v  2 <  3 ^ ) so we the low four bits of each
# character represent the presence of lines in the 4 directions

#_lineAscii = [  5 , 13 , 11 ,  1 , 12 , 14 , 0 , 11 ,
	       #10 ,  2 ,  7 , 13 ,  3 , 10 , 12 , 4   ] # axes wrong
_lineAscii = [ -1 , 10 , 13 ,  2 , 11 ,  7 ,  1 , 13 ,
	       12 ,  3 , 14 , 10 ,  0 , 12 , 11 ,  4   ]
_lineAsciiBase = 0x40006a
  
def cursLineConvK( c ):
  if c:
    return _lineAsciiBase + _lineAscii[ c & 15 ]
  else:
    return 32
def cursLineClear( win ):
  """ Forget all existing lines. Done by removing the window
  from the dictionary of line data, triggering creation of a
  new one (if and when any more lines are drawn)
  """
  if win in _lineData:
    del _lineData[ win ]

def cursLineRefreshPixel( win , y , x ):
  global _lineData
  c = _lineData[ win ][ y ][ x ]
  if c:
    win.addch( y , x , cursLineConvK( c ) )

def cursLineRefresh( win ):
  if win in _lineData:
    ys , xs = win.getmaxyx( )
    for y in range( ys ):
      for x in range( xs ):
	cursLineRefreshPixel( win , y , x )
def cursLineReport( win ):
  if win in _lineData:
    ld = _lineData[ win ]
    return '\n'.join([ ' '.join([ hex( c )[ 2 : ] 
		      for c in row ])  for row in ld ]
                 +  _lineLog )
  else:
    return "No line data for window"
def cursLine( win , y0 , x0 , * yx123 ):
  """ Draw a line on curses window win
  from  y0,x0  to  y1,x1  ... etc
  After y0 , x0 any coord of -1 represents unchanged from
  previous, which should be the case for one of each pair
  if we only draw horizontal and vertical lines.
  A final odd element in yx123 is mode :
  0 (default) - draw the line
  1           - erase the line
  2           - toggle (xor) the line
  """
  global _lineData , _lineAscii , _lineAsciiBase, _lineIds, _lineLog
  win.leaveok( True )  # leave cursor alone during line drawing
  if not win in _lineData:
    # new window to draw lines on
    ys , xs = win.getmaxyx()
    _lineLog.append( "New window's line data to create - %d x % d   " % ( ys , xs ) )
    _lineData[ win ] = [ xs * [ 0 ] for y in range( ys ) ]
    _lineIds[  win ] = len( _lineLog )
  ld = _lineData[ win ]
  id = _lineIds [ win ]
  yx = y0 , x0
  _lineLog.append( "Line on window #%d from ( %2d , %2d ) ..." % ( id , y0 , x0 ) )
  yxs = list ( yx123 )
  mod = 0
  if len( yxs ) & 1:
    mod = yxs.pop( )
  while len( yxs ) > 1:
    yx1 = yxs[ : 2 ]
    _lineLog.append( "               ... to ( %2d , %2d ) ..." % tuple( yx1 ) )
    _lineLog.append( "[ " )
    yxs[ : 2 ] = [ ]
    w = 0
    if -1 in yx1:
      # neatly flagged H or V line with an unchanged coord
      ax = 1 - yx1.index( -1 )
      yx1[ 1 - ax ] = yx[ 1 - ax ]
    else:
      # we'll have to work out H or V or diagonal
      ax = ( abs( yx1[ 1 ] - yx[ 1 ] ) < ( abs( yx1[ 0 ] - yx[ 0 ] ) ) )
      w = yx1[ 1 - ax ] - yx[ 1 - ax ]
      #if w == 0:
	## mark as equal
	#yx1[ 1 - ax ] = -1
    l = yx1[ ax ] - yx[ ax ]
    _lineLog[ - 1 ] += str( l ) + " :"
    #_lineLog[ - 1 ] = _lineLog[ - 1 ] + str( l )
    if l:
      cc = ( ( 2 , 10 , 8 ) , ( 1 , 5 , 4 ) ) [ ax ]
      d = 1
      if l < 0:
	cc = cc[ :: -1 ]
	d = -1
      l2 = l / 2
      for i in range( 0 , l + d , d ):
	c = cc[ ( i != 0 ) + ( i == l ) ]
	yxc = list( yx )
	yxc[   ax   ] += i
	yxc[ 1 - ax ] += ( l2 + i * w ) / l
	yc , xc = yxc
	_lineLog[ - 1 ] += " %d %d" % ( yc , xc )
	if   mod == 0:
	  ld[ yc ][ xc ] |= c
	elif mod == 1:
	  ld[ yc ][ xc ] &= ( 0xf ^ c )
	elif mod == 2:
	  ld[ yc ][ xc ] ^= c
	k = cursLineConvK( ld[ yc ][ xc ] )
	try:
	  win.addch( yc , xc , k )
	except:
	  win.addch( 2 , 2 , k )
	  win.refresh()
	  crs.napms( 2000 )
	  return
	win.refresh()
	## Changed back from following, because it
	# politely declines to print blanks, which
	# is no good when we are deleting lines
	#cursLineRefreshPixel( win , yc , yx )
    yx = list( yx1 )
    _lineLog[ - 1 ] += " ]"
  win.leaveok( False )
def cursLineFrame( win , yx = None , siz = None , mod = 0 ):
  if yx == None:
    yx = 0,0
  y , x = yx
  if siz:
    y1 , x1 = y + siz[ 0 ], x + siz[ 1 ]
  else:  
    y1 , x1 = win.getmaxyx( )
    x1 -= 1
  cursLine( win , y , x , y1 - 1 , -1 , -1 , x1 - 1 , y , -1 , -1 , x , mod )